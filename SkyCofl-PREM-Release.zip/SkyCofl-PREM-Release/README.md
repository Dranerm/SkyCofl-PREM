# SkyCofl-PREM
How do i download this?
- Go to releases and download the LATEST release or build it yourself using the src file

What does this mod do? 
- It's an premium version of coflsky (cofl net mod)

How does it work? 
- It is coded to connect into my premium+ account (i renew my subscriptions every week so don't worry about it not working or sum) 
- However you can not change the config of the flipper, since a ton of people has access to the account

- If you think this is a rat please analyze it yourself or use a scanner tri.age isthisarat and whatever. Then send a proof that it is a rat to my discord
- https://discord.gg/cAhm8s9p7E
